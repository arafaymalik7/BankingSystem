import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import Bank.*;

public class FileIOTest {

    @BeforeEach
    void setUp() {
        // Ensure a clean test environment
        FileIO.bank = new Bank();
    }

    @Test
    void testReadEmptyFile() {
        // Ensure no "data" file exists for a clean test
        File file = new File("data");
        if (file.exists()) {
            file.delete();
        }

        // Read from an empty file
        FileIO.Read();

        // Verify a new Bank object is created
        assertNotNull(FileIO.bank);
        assertEquals(0, FileIO.bank.getAccounts().length);
    }

    @Test
    void testWriteAndReadFile() throws Exception {
        // Add an account and write to file
        BankAccount account = new SavingsAccount("Test User", 5000, 1000);
        FileIO.bank.addAccount(account);
        FileIO.Write();

        // Read back the file
        FileIO.bank = null;
        FileIO.Read();

        // Verify the account was saved and restored
        assertNotNull(FileIO.bank);
        assertEquals(account.getName(), FileIO.bank.getAccounts()[0].getName());
        assertEquals(account.getbalance(), FileIO.bank.getAccounts()[0].getbalance());
    }

    @Test
    void testIOExceptionDuringRead() {
        // Simulate an exception by using an invalid file name
        File originalFile = new File("data");
        File renamedFile = new File("data_backup");
        originalFile.renameTo(renamedFile);

        try {
            FileIO.Read();
        } finally {
            // Restore the original file
            renamedFile.renameTo(originalFile);
        }

        // Ensure a new bank instance is created despite the failure
        assertNotNull(FileIO.bank);
    }
}
