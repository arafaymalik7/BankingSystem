import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Bank.*;
import Exceptions.*;

public class BankTest {

    private Bank bank;
    private SavingsAccount savingsAccount;
    private CurrentAccount currentAccount;

    @BeforeEach
    void setUp() throws Exception {
        bank = new Bank();
        savingsAccount = new SavingsAccount("John Doe", 5000, 1000);
        currentAccount = new CurrentAccount("Jane Smith", 10000, "TL12345");
        bank.addAccount(savingsAccount);
        bank.addAccount(currentAccount);
    }

    @Test
    void testAddAccount() {
        BankAccount newAccount = new SavingsAccount("Alice", 3000, 500);
        int accountIndex = bank.addAccount(newAccount);
        assertEquals(newAccount, bank.getAccounts()[accountIndex]);
    }

    @Test
    void testFindAccount() {
        BankAccount foundAccount = bank.findAccount(savingsAccount.acc_num);
        assertNotNull(foundAccount);
        assertEquals(savingsAccount.acc_num, foundAccount.acc_num);

        assertNull(bank.findAccount("NonExistent"));
    }

    @Test
    void testDeposit() throws Exception {
        double depositAmount = 2000;
        double expectedBalance = savingsAccount.getbalance() + depositAmount;
        bank.deposit(savingsAccount.acc_num, depositAmount);
        assertEquals(expectedBalance, savingsAccount.getbalance());

        assertThrows(InvalidAmount.class, () -> bank.deposit(savingsAccount.acc_num, -1000));
        assertThrows(AccNotFound.class, () -> bank.deposit("InvalidAccount", 1000));
    }

    @Test
    void testWithdraw() throws Exception {
        double withdrawAmount = 1000;
        double expectedBalance = currentAccount.getbalance() - withdrawAmount;
        bank.withdraw(currentAccount.acc_num, withdrawAmount);
        assertEquals(expectedBalance, currentAccount.getbalance());

        assertThrows(MaxBalance.class, () -> bank.withdraw(currentAccount.acc_num, 20000));
        assertThrows(MaxWithdraw.class, () -> savingsAccount.withdraw(2000));
        assertThrows(InvalidAmount.class, () -> bank.withdraw(currentAccount.acc_num, -500));
        assertThrows(AccNotFound.class, () -> bank.withdraw("InvalidAccount", 500));
    }
}

