import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Bank.*;

public class BankAccountTest {

    private BankAccount bankAccount;

    @BeforeEach
    void setUp() {
        bankAccount = new BankAccount("Test User", 5000, 2000);
    }

    @Test
    void testBankAccountInitialization() {
        assertEquals("Test User", bankAccount.getName());
        assertEquals(5000, bankAccount.getbalance());
        assertEquals(2000, bankAccount.min_balance);
    }

    @Test
    void testDeposit() {
        bankAccount.deposit(1000);
        assertEquals(6000, bankAccount.getbalance());

        assertThrows(IllegalArgumentException.class, () -> bankAccount.deposit(-500));
    }

    @Test
    void testWithdraw() throws Exception {
        bankAccount.withdraw(1000);
        assertEquals(4000, bankAccount.getbalance());

        assertThrows(Exception.class, () -> bankAccount.withdraw(6000));
        assertThrows(Exception.class, () -> bankAccount.withdraw(-500));
    }
}
