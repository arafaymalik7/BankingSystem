import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import Exceptions.*;

public class ExceptionsTest {

    @Test
    void testAccNotFoundException() {
        AccNotFound exception = assertThrows(AccNotFound.class, () -> {
            throw new AccNotFound("Account not found.");
        });
        assertEquals("Account not found.", exception.getMessage());
    }

    @Test
    void testInvalidAmountException() {
        InvalidAmount exception = assertThrows(InvalidAmount.class, () -> {
            throw new InvalidAmount("Invalid amount.");
        });
        assertEquals("Invalid amount.", exception.getMessage());
    }

    @Test
    void testMaxBalanceException() {
        MaxBalance exception = assertThrows(MaxBalance.class, () -> {
            throw new MaxBalance("Maximum balance exceeded.");
        });
        assertEquals("Maximum balance exceeded.", exception.getMessage());
    }

    @Test
    void testMaxWithdrawException() {
        MaxWithdraw exception = assertThrows(MaxWithdraw.class, () -> {
            throw new MaxWithdraw("Maximum withdrawal limit exceeded.");
        });
        assertEquals("Maximum withdrawal limit exceeded.", exception.getMessage());
    }
}
