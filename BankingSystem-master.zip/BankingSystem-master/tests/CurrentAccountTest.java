import Bank.CurrentAccount;

public class CurrentAccountTest {

    private CurrentAccount currentAccount;

    @BeforeEach
    void setUp() throws Exception {
        currentAccount = new CurrentAccount("Jane Doe", 6000, "TL98765");
    }

    @Test
    void testCurrentAccountInitialization() {
        assertEquals("Jane Doe", currentAccount.getName());
        assertEquals(6000, currentAccount.getbalance());
        assertEquals("TL98765", currentAccount.tradeLicenseNumber);
    }

    @Test
    void testInsufficientBalanceInitialization() {
        assertThrows(Exception.class, () -> new CurrentAccount("John Doe", 3000, "TL12345"));
    }
}
