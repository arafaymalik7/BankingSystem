import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Bank.*;
import Exceptions.*;

public class StudentAccountTest {

    private StudentAccount studentAccount;

    @BeforeEach
    void setUp() {
        studentAccount = new StudentAccount("Bob", 500, "XYZ University");
    }

    @Test
    void testStudentAccountInitialization() {
        assertEquals("Bob", studentAccount.getName());
        assertEquals(500, studentAccount.getbalance());
        assertEquals("XYZ University", studentAccount.institutionName);
        assertEquals(100, studentAccount.min_balance);
    }

    @Test
    void testWithdrawWithinLimit() throws Exception {
        studentAccount.withdraw(100);
        assertEquals(400, studentAccount.getbalance());
    }

    @Test
    void testWithdrawBelowMinimumBalance() {
        assertThrows(MaxBalance.class, () -> studentAccount.withdraw(450));
    }

    @Test
    void testNegativeWithdrawal() {
        assertThrows(InvalidAmount.class, () -> studentAccount.withdraw(-50));
    }
}
