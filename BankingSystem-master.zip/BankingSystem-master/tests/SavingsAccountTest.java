import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Bank.*;
import Exceptions.*;

public class SavingsAccountTest {

    private SavingsAccount savingsAccount;

    @BeforeEach
    void setUp() {
        savingsAccount = new SavingsAccount("Alice", 5000, 1000);
    }

    @Test
    void testSavingsAccountInitialization() {
        assertEquals("Alice", savingsAccount.getName());
        assertEquals(5000, savingsAccount.getbalance());
        assertEquals(1000, savingsAccount.maxWithLimit);
    }

    @Test
    void testGetNetBalance() {
        double expectedNetBalance = 5000 + (5000 * 0.05);
        assertEquals(expectedNetBalance, savingsAccount.getNetBalance());
    }

    @Test
    void testWithdraw() throws Exception {
        savingsAccount.withdraw(500);
        assertEquals(4500, savingsAccount.getbalance());

        assertThrows(MaxWithdraw.class, () -> savingsAccount.withdraw(1500));
        assertThrows(MaxBalance.class, () -> savingsAccount.withdraw(6000));
    }

    @Test
    void testNegativeWithdrawal() {
        assertThrows(InvalidAmount.class, () -> savingsAccount.withdraw(-100));
    }
}
